library(testthat)
library(GpGp2)

test_check("GpGp2")
